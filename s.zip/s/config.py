# Pyrogram setup
API_ID = 21902589
API_HASH = "646d988e7c7938f85ca652ece00b07ba"
SESSION_STRING = ""  # Optional: only needed for /scr (card scraping). Generate via pyrogram string session generator.

DEFAULT_LIMIT = 1000  # Card Scrapping Limit For Everyone
PREMIUM_LIMIT = 5000  # Card Scrapping Limit For Premium Users

# Cooldown settings (in seconds)
COOLDOWN_FREE = 10  # Cooldown for Free users
COOLDOWN_TRIAL = 10  # Cooldown for Trial users

# Credit cost per command
CREDIT_COST = 2  # Credits deducted for each successful command

# =============================================================================
# API Endpoints
# =============================================================================
SHOPIFY_API_URL = "https://xaeden.onrender.com/sh"
SHOPIFY_MASS_API_URL = "https://xaeden.onrender.com/sh"
SHOPIFY_SETURL_API_URL = "https://xaeden.onrender.com/sh"
STRIPE_API_URL = "https://blackxcard-autostripe.onrender.com"
STRIPE_AUTH_API_URL = "https://blackxcard-autostripe.onrender.com"
BRAINTREE_API_URL = "https://blackxcard-autostripe.onrender.com"
RAZORPAY_API_URL = "https://rzp.victus.name/rzpv2"
PAYPAL_API_URL = "https://blackxcard-autostripe.onrender.com"
PAYPAL_PROXY_API_URL = "https://blackxcard-autostripe.onrender.com"
CVV_API_URL = "https://blackxcard-autostripe.onrender.com"
VBV_API_URL = "https://blackxcard-autostripe.onrender.com"
PAYU_API_URL = "https://blackxcard-autostripe.onrender.com"
PAYFAST_API_URL = "https://blackxcard-autostripe.onrender.com"
